import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.{StructType, StructField, StringType, IntegerType}

object Assignment01Scala {
  def main(args: Array[String]): Unit = {
    // Create SparkSession
    val spark = SparkSession.builder
      .appName("Assignment 01 - Scala")
      .getOrCreate()

    // Path to the CSV file
    val csvFilePath = "Divvy_Trips_2015-Q1.csv"

    // First DataFrame: Infer Schema
    val dfInferSchema = spark.read.option("header", "true").csv(csvFilePath)
    println("DataFrame with Inferred Schema:")
    dfInferSchema.printSchema()
    println("Number of records: " + dfInferSchema.count())

    // Second DataFrame: Programmatically Define Schema
    val schema = new StructType()
      .add("trip_id", IntegerType)
      .add("starttime", StringType)
      .add("stoptime", StringType)
      .add("bikeid", IntegerType)
      .add("tripduration", StringType)
      .add("from_station_name", StringType)
      .add("to_station_name", StringType)
      .add("usertype", StringType)
      .add("gender", StringType)
      .add("birthyear", StringType)

    val dfProgrammaticSchema = spark.read.option("header", "true").schema(schema).csv(csvFilePath)
    println("DataFrame with Programmatically Defined Schema:")
    dfProgrammaticSchema.printSchema()
    println("Number of records: " + dfProgrammaticSchema.count())

    // Third DataFrame: Attach Schema via DDL
    val ddlSchema = "trip_id INT, starttime STRING, stoptime STRING, bikeid INT, tripduration STRING, from_station_name STRING, to_station_name STRING, usertype STRING, gender STRING, birthyear STRING"
    val dfDdlSchema = spark.read.option("header", "true").schema(ddlSchema).csv(csvFilePath)
    println("DataFrame with Schema Attached via DDL:")
    dfDdlSchema.printSchema()
    println("Number of records: " + dfDdlSchema.count())

    // Select Gender based on last name
    val lastName = "Sangolli"
    val gender = if (lastName.toLowerCase <= "k") "female" else "male"
    println("Selected Gender based on last name: " + gender)

    // GroupBy station_name and show 10 records
    val dfGrouped = dfInferSchema.groupBy("from_station_name").count()
    println("Grouped DataFrame:")
    dfGrouped.show(10)

    // Stop SparkSession
    spark.stop()
  }
}
